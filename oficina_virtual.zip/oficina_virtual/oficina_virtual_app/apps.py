from django.apps import AppConfig

class OficinaVirtualAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'oficina_virtual_app'
