from django.contrib.auth import get_user_model
from dj_rest_auth.views import LoginView
from rest_framework.response import Response

User = get_user_model()

class CustomLoginView(LoginView):
    def get_response(self):
        orginal_response = super().get_response()
        mydata = {"user_type": self.user.user_type}  
        orginal_response.data.update(mydata)
        return orginal_response
