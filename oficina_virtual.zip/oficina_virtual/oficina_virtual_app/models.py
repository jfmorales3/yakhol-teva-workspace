from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):

    user_type = models.PositiveSmallIntegerField(choices=[(1, 'admin'), (2, 'comercial'), (3, 'asociado')], default=1)
